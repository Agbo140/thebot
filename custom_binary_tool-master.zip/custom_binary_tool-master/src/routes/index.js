import Routes from './Routes.jsx';

export default Routes;
