import Modal from './modal.jsx';

export default Modal;
