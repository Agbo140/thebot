import Load from './load.jsx';

export default Load;
