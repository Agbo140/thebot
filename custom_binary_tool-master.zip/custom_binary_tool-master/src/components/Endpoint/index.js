import Endpoint from './Endpoint.jsx';

export default Endpoint;
